<footer>
    <footer class="footer">
        <p>© 2025 Midnight Waiting by Alexa Cueto</p>
</footer>
</body>
</html>
