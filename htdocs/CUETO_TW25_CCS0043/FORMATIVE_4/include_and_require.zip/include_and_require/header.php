<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Midnight Waiting</title>
    <link rel="stylesheet" href="style.css" />
</head>
<body>
    <header class="site-header">
        <h1>Midnight Waiting</h1>
        <nav>
            <a href="index.php">Homepage</a>
        </nav>
    </header>
